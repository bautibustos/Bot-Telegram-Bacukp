#NumeroUno es la variable.
#El int es el tipo de dato, en este caso un dato entero.
#El inputo muestra el texto y espera un ingreso de datos.
NumeroUno= int(input('Ingrese el primero numero ')) 

NumeroDos= int(input('Ingrese el segundo numero '))

Total= NumeroDos+NumeroUno # Esto es una variable que calcula una suma
#para divir en python se usa la "/" para Restar se usa "-" para multiplicar "*"
#para hacer la potencia de un numero se usa "**" para el resto de una division se usa %

print("La suma es: ",Total)#esto es el escribir de pseudocodigo, muestra un texto
	#lo que va entre comillas es el texto, y lo que esta afuera es el contenido de la variable
